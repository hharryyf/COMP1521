./stu 65.0 tests/s1.dat
