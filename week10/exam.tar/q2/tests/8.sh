./stu 50 tests/s3.dat
