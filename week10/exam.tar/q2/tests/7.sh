./stu 0 tests/s3.dat
