exe tests/s5.s
