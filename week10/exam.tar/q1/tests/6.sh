exe tests/s6.s
